create table t1(c1 int primary key,c2 int);
desc t1;

